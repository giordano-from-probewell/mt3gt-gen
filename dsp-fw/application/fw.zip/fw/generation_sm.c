#include "generation_sm.h"
#include <math.h>


// clamp
static inline float32_t clamp01(float32_t x) {
    if (x < 0.0f) return 0.0f;
    if (x > 1.0f) return 1.0f;
    return x;
}

static void apply_scale(gen_sm_ch_t *ch, float32_t s)
{
    s = clamp01(s);
    ch->scale_cur = s;
    ch->wg->config.scale = s;   // mirror
}

void gen_sm_init(gen_sm_ch_t *ch,
                 waveform_generation_t *wg,
                 const gen_sm_hw_cb_t *hw,
                 float32_t ramp_slew_per_tick,
                 uint32_t tick_period_ms)
{
    ch->wg = wg;
    ch->hw = *hw;
    ch->ramp_slew     = (ramp_slew_per_tick > 0.f) ? ramp_slew_per_tick : 0.01f;
    ch->tick_period_ms= (tick_period_ms != 0u) ? tick_period_ms : 5u;

    ch->state = GEN_SM_OFF;
    ch->next_tick_ms = 0;
    ch->scale_cur = 0.f;
    apply_scale(ch, 0.f);

    // espelha flags iniciais
    ch->wg->status.ready_to_generate = false;
    ch->wg->status.generating        = false;
}

void gen_sm_request_enable(gen_sm_ch_t *ch)
{
    if (ch->state == GEN_SM_OFF || ch->state == GEN_SM_DISARMING) {
        ch->state = GEN_SM_ARMING;
    }
}

void gen_sm_request_disable(gen_sm_ch_t *ch)
{
    if (ch->state == GEN_SM_RUN || ch->state == GEN_SM_RAMP_UP) {
        ch->state = GEN_SM_RAMP_DOWN;
        ch->wg->config.scale_requested = 0.f;
    }
}

void gen_sm_request_scale(gen_sm_ch_t *ch, float32_t new_scale)
{
    ch->wg->config.scale_requested = clamp01(new_scale);
    if (ch->state == GEN_SM_RUN) {
        // inicia micro rampa dentro do RUN
        if (ch->wg->config.scale_requested > ch->scale_cur)
            ch->state = GEN_SM_RAMP_UP;
        else if (ch->wg->config.scale_requested < ch->scale_cur)
            ch->state = GEN_SM_RAMP_DOWN;
    }
}

void gen_sm_fault(gen_sm_ch_t *ch)
{
    ch->state = GEN_SM_FAULT;
    if (ch->hw.pwm_force_trip) ch->hw.pwm_force_trip();
    if (ch->hw.cla_off_task)   ch->hw.cla_off_task();
    ch->wg->status.generating = false;
}

static void step_ramp_to(gen_sm_ch_t *ch, float32_t target)
{
    float32_t s = ch->scale_cur;
    if (fabsf(target - s) <= ch->ramp_slew) {
        s = target;
    } else if (target > s) {
        s += ch->ramp_slew;
    } else {
        s -= ch->ramp_slew;
    }
    apply_scale(ch, s);
}

void gen_sm_tick(gen_sm_ch_t *ch, my_time_t now)
{
    if (now < ch->next_tick_ms) return;
    ch->next_tick_ms = now + ch->tick_period_ms;

    // atalhos a flags de proteção/command
    bool prot_err = ch->wg->command.disable_from_protection_by_control_error ||
                    ch->wg->command.disable_from_protection_by_saturation;

    if (prot_err && ch->state != GEN_SM_OFF && ch->state != GEN_SM_FAULT) {
        gen_sm_fault(ch);
        return;
    }

    switch (ch->state) {
    case GEN_SM_OFF:
        // esperando enable externo (CLI/IPC)
        if (ch->wg->command.enable || ch->wg->command.enable_from_cli || ch->wg->command.enable_from_comm) {
            ch->state = GEN_SM_ARMING;
        }
        break;

    case GEN_SM_ARMING:
        if (ch->hw.pwm_clear_trip) ch->hw.pwm_clear_trip();
        if (ch->hw.cla_on_task)    ch->hw.cla_on_task();
        ch->wg->status.ready_to_generate = true;
        ch->wg->status.generating        = true;

        // decide alvo inicial
        if (ch->wg->config.scale_requested <= ch->scale_cur) {
            ch->state = GEN_SM_RUN;
        } else {
            ch->state = GEN_SM_RAMP_UP;
        }
        break;

    case GEN_SM_RAMP_UP:
        step_ramp_to(ch, ch->wg->config.scale_requested);
        if (ch->scale_cur >= ch->wg->config.scale_requested) {
            ch->state = GEN_SM_RUN;
        }
        break;

    case GEN_SM_RUN:
        // nada pesado aqui, só vigia pedidos
        if (ch->wg->command.disable || ch->wg->command.disable_from_cli || ch->wg->command.disable_from_comm) {
            ch->state = GEN_SM_RAMP_DOWN;
            ch->wg->config.scale_requested = 0.f;
        }
        break;

    case GEN_SM_RAMP_DOWN:
        step_ramp_to(ch, 0.f);
        if (ch->scale_cur <= 0.f) {
            ch->state = GEN_SM_DISARMING;
        }
        break;

    case GEN_SM_DISARMING:
        if (ch->hw.pwm_force_trip) ch->hw.pwm_force_trip();
        if (ch->hw.cla_off_task)   ch->hw.cla_off_task();
        ch->wg->status.generating        = false;
        ch->wg->status.ready_to_generate = false;
        ch->state = GEN_SM_OFF;
        break;

    case GEN_SM_FAULT:
    default:
        // fica parado até alguém limpar as flags e pedir enable novamente
        break;
    }
}

void gen_sm_change_waveform_soft(gen_sm_ch_t *ch, reference_generation_t *new_ref)
{
    // desce
    ch->wg->config.scale_requested = 0.f;
    ch->state = GEN_SM_RAMP_DOWN;
    // a aplicação: chame gen_sm_tick até chegar em DISARMING->OFF,
    // troque a referência e volte a habilitar
    (void)new_ref; // troca física da ref deve ocorrer no ponto em que scale==0
}


