#include "generic_definitions.h"

char *INITIALIZED = {"yes"};



